

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Cover Types</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $cover_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cover_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <?php echo e($cover_type); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    


                    
                        
                </div>
            </div>


            <div class="panel panel-default">
                <div class="panel-heading">New cover</div>
                <div class="panel-body">


                    <div>
                        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
                    
                        <form action="#" method="post" id="new_cover_type" onsubmit="return false;">
                        <?php echo e(csrf_field()); ?>

                            <!-- setting the type to button make it not submit the form // by default when clicked it will submit the form to the url in action -->
                            <button id="new_cover" type="button">Add new cover</button>
                            <input id="coversSubmit" type="submit" name="Done">
                        </form>
                    </div>


                </div>
            </div>




        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>