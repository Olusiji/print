

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Vendor Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo e($vendor->id); ?>

                    <?php echo e($vendor->name); ?>

                    <?php echo e($vendor->photolab_name); ?>

                    <?php echo e($vendor->email); ?>

                    <?php echo e($vendor->phone_number); ?>

                    <?php echo e($vendor->address); ?>

                    <?php echo e($vendor->city); ?>

                    <?php echo e($vendor->state); ?>


                    <a href="<?php echo e(route('vendor.profile.edit')); ?>" class="btn btn-info" role="button">Edit Profile</a>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>