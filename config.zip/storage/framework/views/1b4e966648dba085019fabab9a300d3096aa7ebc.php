

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-heading">Sizes</div>

                <div class="">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div>
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
                    
                    <form action="#" method="post" id="sizes" onsubmit="return false;">
                    <?php echo e(csrf_field()); ?>

                        <!-- setting the type to button make it not submit the form // by default when clicked it will submit the form to the url in action -->
                        <button id="new_size" type="button">Add new size</button>
                        <input id="sizesSubmit" type="submit" name="Done">
                    </form>
                </div>

            </div>
        </div>




        <div class="col-md-12">
            <div class="panel">
                <div class="panel-heading">Cover Types</div>


                <div>
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
                    
                    <form action="#" method="post" id="covers" onsubmit="return false;">

                        <!-- setting the type to button makes it not submit the form // by default when clicked it will submit the form to the url in action -->
                        <button id="new_cover" type="button">Add new cover</button>
                        <input id="coversSubmit" type="submit" name="Done">
                    </form>

                </div>  

            </div>
        </div>



        <div class="col-md-12">
            <div class="panel">
                <div class="panel-heading">Page size prices</div>

                <div id="coverpricing">
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
                    
                    <form action="#" method="post" id="coversprice" onsubmit="return false;">
                    <?php echo e(csrf_field()); ?>

                        <!-- setting the type to button makes it not submit the form // by default when clicked it will submit the form to the url in action -->
                        <input type="text" name="size" placeholder="">

                        <input id="coversSubmit" type="submit" name="Done">
                    </form>

                </div>  

            </div>
        </div>
































    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>