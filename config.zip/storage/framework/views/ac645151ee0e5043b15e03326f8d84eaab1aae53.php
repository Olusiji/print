

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Vendor Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(count($jobs) == 0): ?>
                        <p>You have not gotten any job yet</p>
                    <?php else: ?>
                        <table border="1" class="table">
                            <tbody>
                                <tr>
                                    <td>Job Name</td>
                                    <td>Total Cost</td>
                                    <td>Order Date</td>
                                    <td>Job Details</td>
                                </tr>  
                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                    <tr>
                                        <td><?php echo e($job->job_name); ?></td>
                                        <td><?php echo e($job->cost); ?></td>
                                        <td><?php echo e($job->created_at); ?></td>
                                        <td><a href="<?php echo e(route("vendor.job_items", ['id' => $job->id])); ?>">View job details</a></td>
                                    </tr>                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>