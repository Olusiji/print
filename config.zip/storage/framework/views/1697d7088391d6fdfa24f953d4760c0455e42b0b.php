

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Vendor Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('vendor.covers.prices.edit.submit')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                    <?php $__currentLoopData = $cover_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cover_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <fieldset>
                            <legend><?php echo e($cover_type); ?></legend>

                            <?php $__currentLoopData = $covers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cover): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $cover->cover_type == $cover_type ): ?>
                                    <label><?php echo e($cover->size); ?></label>
                                    <input type="text" name="<?php echo e($cover->id); ?>" value="<?php echo e($cover->price); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </fieldset>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn btn-default" type="submit">Submit</button>
                    </form>
               

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>