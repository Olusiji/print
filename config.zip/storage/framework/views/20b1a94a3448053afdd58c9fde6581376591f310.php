

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Vendor Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('vendor.profile.edit.submit')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo e($vendor->name); ?>">

                        <label>Photolab Name</label>
                        <input type="text" name="photolab_name" value="<?php echo e($vendor->photolab_name); ?>">

                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo e($vendor->email); ?>">

                        <label>Phone Number</label>
                        <input type="text" name="phone_number" value="<?php echo e($vendor->phone_number); ?>">

                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo e($vendor->address); ?>">

                        <label>City</label>
                        <input type="text" name="city" value="<?php echo e($vendor->city); ?>">

                        <label>State</label>
                        <input type="text" name="state" value="<?php echo e($vendor->state); ?>">

                        <button class="btn btn-default" type="submit">Submit</button>
                    </form>
               

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>