<?php if(Auth::guard('web')->check()): ?>
	<p class="text-success">
		You are logged in as a <strong>USER</strong>
	</p>
<?php else: ?>
	<p class="text-danger">
		You are logged out as a <strong>USER</strong>
	</p>
<?php endif; ?>

<?php if(Auth::guard('vendor')->check()): ?>
	<p class="text-success">
		You are logged in as a <strong>VENDOR</strong>
	</p>
<?php else: ?>
	<p class="text-danger">
		You are logged out as a <strong>VENDOR</strong>
	</p>
<?php endif; ?>